package main;

public interface Calculator {
    int add(String str);
}
