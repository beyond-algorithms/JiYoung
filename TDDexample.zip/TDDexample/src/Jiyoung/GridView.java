package Jiyoung;

public class GridView {
    Form form = Form.getInstance();


}
